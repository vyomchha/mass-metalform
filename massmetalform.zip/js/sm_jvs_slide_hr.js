var mql = window.matchMedia("(orientation: portrait)");
mql.addListener(function(m) {
	if(m.matches) {
		// Changed to portrait
		var bd_slide_image = document.getElementsByClassName("slide_main");
		bd_slide_image[0].style.display = "block";
	}
	else {
		// Changed to landscape
		var bd_slide_image = document.getElementsByClassName("slide_main");
		bd_slide_image[0].style.display = "none";
	}
});

function change_col2(n) {
	var bd_slide_image = document.getElementsByClassName("slide_page_body_col2_dat");
	for (i = 0; i < bd_slide_image.length; i++) {
	  	bd_slide_image[i].style.display = "none";
	}
	bd_slide_image[n-1].style.display = "block";
	change_col3(0);
}

function change_col3(n) {
	var bd_slide_image = document.getElementsByClassName("slide_page_body_col3_dat");
	for (i = 0; i < bd_slide_image.length; i++) {
	  	bd_slide_image[i].style.display = "none";
	}
	bd_slide_image[n-1].style.display = "block";
}
